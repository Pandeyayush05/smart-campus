<style>
  body {
    font-family: "Poppins", sans-serif;
    margin: 0;
    padding: 0;
    background: #f8fafc;
    color: #333;
    scroll-behavior: smooth;
  }

  /* ===== Hero Section ===== */
  .hero {
    text-align: center;
    padding: 60px 20px 40px;
    background: linear-gradient(135deg, #007bff, #00aaff);
    color: white;
  }
  .hero h1 {
    font-size: 36px;
    margin-bottom: 10px;
  }
  .hero p {
    font-size: 16px;
    opacity: 0.9;
  }

  /* ===== Staff Cards Section ===== */
  .staff-container {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 25px;
    padding: 60px 20px;
  }

  .staff-card {
    background: white;
    border-radius: 15px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.08);
    width: 260px;
    text-align: center;
    padding: 25px 20px;
    transition: all 0.3s ease;
  }

  .staff-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
  }

  .staff-card img {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    margin-bottom: 15px;
    object-fit: cover;
  }

  .staff-card h3 {
    color: #007bff;
    font-size: 18px;
    margin: 8px 0 4px;
  }

  .staff-card p {
    font-size: 14px;
    color: #555;
    margin-bottom: 10px;
  }

  .staff-card span {
    display: inline-block;
    background: #007bff;
    color: white;
    font-size: 13px;
    padding: 5px 12px;
    border-radius: 20px;
    margin-top: 6px;
  }

  /* ===== Scroll to Top Button ===== */
  #scrollToTopBtn {
    position: fixed;
    bottom: 25px;
    right: 25px;
    background-color: #007bff;
    color: white;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 10px 14px;
    border-radius: 50%;
    font-size: 18px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
    display: none;
    z-index: 99;
  }
  #scrollToTopBtn:hover {
    background-color: #0056b3;
    transform: translateY(-3px);
  }

  /* ===== Footer ===== */
  footer {
    background: #0d1b2a;
    color: #e0e6ed;
    padding: 50px 20px 25px;
  }

  .footer-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 40px;
    max-width: 1100px;
    margin: 0 auto;
  }

  .footer-column {
    flex: 1 1 220px;
    min-width: 200px;
  }

  .footer-column h3 {
    color: #00aaff;
    margin-bottom: 15px;
    font-size: 18px;
    border-left: 4px solid #00aaff;
    padding-left: 8px;
  }

  .footer-column p {
    font-size: 14px;
    color: #cdd6e0;
    line-height: 1.6;
  }

  .footer-column ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .footer-column ul li {
    margin: 6px 0;
  }

  .footer-column ul li a {
    color: #e0e6ed;
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s;
  }

  .footer-column ul li a:hover {
    color: #00aaff;
  }

  .footer-bottom {
    margin-top: 40px;
    font-size: 13px;
    color: #bbb;
    text-align: center;
    border-top: 1px solid rgba(255,255,255,0.1);
    padding-top: 15px;
  }

  @media (max-width: 700px) {
    .footer-container {
      flex-direction: column;
      text-align: center;
    }
    .footer-column h3 {
      border: none;
      padding-left: 0;
    }
  }
</style>
</head>
<body>

<!-- Hero Section -->
<style>

/* ===== HERO ===== */
.hero {
  text-align: center;
  padding: 80px 20px 50px;
  background: linear-gradient(135deg, #007bff, #00c6ff);
  color: white;
}

.hero h1 {
  font-size: 40px;
  font-weight: 700;
  letter-spacing: 1px;
}

.hero span:first-child {
  color: #fff;
}

.hero span:last-child {
  color: #00ffcc;
}

.hero p {
  font-size: 16px;
  margin-top: 10px;
  opacity: 0.9;
}

/* ===== STAFF SECTION ===== */
.staff-container {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 30px;
  padding: 70px 20px;
  background: #f8fafc;
}

/* Card */
.staff-card {
  background: #fff;
  border-radius: 20px;
  width: 260px;
  text-align: center;
  padding: 25px 20px;
  transition: 0.4s;
  position: relative;

  box-shadow: 0 10px 25px rgba(0,0,0,0.08);
}

/* Hover effect */
.staff-card:hover {
  transform: translateY(-12px) scale(1.03);
  box-shadow: 0 20px 45px rgba(0,0,0,0.15);
}

/* Image Circle */
.staff-card img {
  width: 90px;
  height: 90px;
  border-radius: 50%;
  object-fit: cover;
  margin-bottom: 15px;

  border: 4px solid #fff;
  box-shadow: 0 0 0 4px #007bff20;
  transition: 0.4s;
}

/* Image Hover Glow */
.staff-card:hover img {
  box-shadow: 0 0 0 6px #007bff40;
  transform: scale(1.05);
}

/* Name */
.staff-card h3 {
  color: #222;
  font-size: 18px;
  margin: 10px 0 5px;
}

/* Role */
.staff-card p {
  font-size: 14px;
  color: #007bff;
  font-weight: 500;
}

/* Social Icons */
.social {
  margin-top: 12px;
  opacity: 0;
  transform: translateY(10px);
  transition: 0.4s;
}

.staff-card:hover .social {
  opacity: 1;
  transform: translateY(0);
}

.social a {
  display: inline-block;
  margin: 0 5px;
  width: 32px;
  height: 32px;
  line-height: 32px;
  border-radius: 50%;
  background: #f1f5f9;
  color: #007bff;
  transition: 0.3s;
}

.social a:hover {
  background: #007bff;
  color: white;
  transform: translateY(-4px);
}

/* Scroll animation */
.fade-up {
  opacity: 0;
  transform: translateY(40px);
  transition: 1s;
}

.fade-up.show {
  opacity: 1;
  transform: translateY(0);
}

</style>

<!-- HERO -->
<section class="hero">
  <h1>
    <span>SmartCampus</span>
    <span>Connect</span>
  </h1>
  <p>Empowering Students for Tomorrow through Education, Innovation, and Integrity</p>
</section>

<!-- STAFF -->
<section class="staff-container fade-up">

  <div class="staff-card">
    <img src="Images/Rishabh.png">
    <h3>Mr. Rishabh Vashisht</h3>
    <p>Mentor</p>
    <div class="social">
      <a href="https://www.instagram.com/rishbhvashisht09"><i class='bx bxl-instagram'></i></a>
    </div>
  </div>

  <div class="staff-card">
    <img src="Images/Ayush.jpg">
    <h3>Ayush Pandey</h3>
    <p></p>
    <div class="social">
      <a href="https://www.instagram.com/pandeyayush05"><i class='bx bxl-instagram'></i></a>
    </div>
  </div>

  <div class="staff-card">
    <img src="Images/Alka.png">
    <h3>Alka Rautela</h3>
    <p></p>
    <div class="social">
      <a href="https://www.instagram.com/me_alka05"><i class='bx bxl-instagram'></i></a>
    </div>
  </div>

  <div class="staff-card">
    <img src="Images/Aryan.png">
    <h3>Aryan Singh</h3>
    <p></p>
    <div class="social">
      <a href="https://www.instagram.com/aryanmatiyali"><i class='bx bxl-instagram'></i></a>
    </div>
  </div>

</section>

<script>
// Scroll animation
const section = document.querySelector('.fade-up');

window.addEventListener('scroll', () => {
  if (section.getBoundingClientRect().top < window.innerHeight - 100) {
    section.classList.add('show');
  }
});
</script>

<!-- Scroll to Top Button -->
<button id="scrollToTopBtn" title="Go to top">↑</button>

<!-- Footer -->
<footer>
  <div class="footer-container">
    <div class="footer-column">
      <h3>About us</h3>
      <p>SmartCampus Connect develops academic excellence, creativity, and leadership for future success.</p>
    </div>

    <div class="footer-column">
      <h3>Quick Links</h3>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="http://localhost/smartcampus/login.php">Admin</a></li>
        <li><a href="http://localhost/smartcampus/login.php">Students</a></li>
        <li><a href="http://localhost/smartcampus/login.php">Teachers</a></li>
      </ul>
    </div>

    <div class="footer-column">
      <h3>Academics</h3>
      <ul>
        <li><a href="http://localhost/smartcampus/login.php">Subjects</a></li>
        <li><a href="http://localhost/smartcampus/login.php">Timetable</a></li>
        <li><a href="http://localhost/smartcampus/login.php">Results</a></li>
        <li><a href="http://localhost/smartcampus/login.php">Library</a></li>
      </ul>
    </div>

    <div class="footer-column">
      <h3>Contact Us</h3>
      <ul>
        <p><b>SmartCampus Connect</b></p>
        <li>📞  +91 7017703657</li>
        <li>✉️ <a href="mailto:pandeyayush6184@gmail.com">pandeyayush6184@gmail.com</a></li>
        <a href="https://www.instagram.com/pandeyayush05" target="_blank" aria-label="Instagram">Instagram-Admin</a><br>
      </ul>
    </div>
  </div>

  <div class="footer-bottom">
    © 2026 SmartCampus Connect — All Rights Reserved.
  </div>
</footer>

<script>
  const scrollBtn = document.getElementById("scrollToTopBtn");
  window.addEventListener("scroll", () => {
    scrollBtn.style.display = window.scrollY > 200 ? "block" : "none";
  });
  scrollBtn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
</script>
