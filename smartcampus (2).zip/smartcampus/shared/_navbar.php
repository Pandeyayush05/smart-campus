<header>
  <div class="container">
    <div class="logo">
      <a href="./index.php">
        <img src="./images/logo.png" alt="Logo" />
        
      </a>
      <a href="./login.php">
        <h3>  SmartCampus </h3>
</h3>
      </a>
    </div>

    <div class="nav-container">

      <div class="links">
        <ul>
          <li><a href="./index.php">Home</a></li>
          <li><a href="./blog.php">Blog</a></li>
          <li><a href="./about-us.php">About</a></li>
          <li><a href="./contact-us.php">Contact</a></li>
          <li><a href="./login.php" class="btn">Login</a></li>
        </ul>


      </div>
      <div class="bottom-area">
        <div class="container">
          
        </div>
      </div>
    </div>
    <div class="overlay"></div>

    <div class="hamburger-menu">
      <div class="bar"></div>
    </div>
  </div>
</header>