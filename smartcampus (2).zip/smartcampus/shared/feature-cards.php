<style>

/* Section */
.card-container {
  padding: 90px 20px;
  background: linear-gradient(to bottom, #ffffff, #f4f7fb);
}

/* Card */
.card {
  background: #fff;
  border-radius: 25px;
  padding: 30px 20px;
  text-align: center;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;

  box-shadow: 
    0 10px 25px rgba(0,0,0,0.05),
    0 5px 10px rgba(0,0,0,0.03);
}

/* Soft Glow Background */
.card::after {
  content: "";
  position: absolute;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(0,123,255,0.15), transparent 70%);
  top: -50%;
  left: -50%;
  opacity: 0;
  transition: 0.5s;
}

/* Shine Effect */
.card::before {
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: linear-gradient(120deg, transparent, rgba(255,255,255,0.6), transparent);
  top: 0;
  left: -100%;
  transition: 0.6s;
}

/* Hover */
.card:hover {
  transform: translateY(-15px) scale(1.04);
  box-shadow: 
    0 20px 40px rgba(0,0,0,0.12),
    0 10px 20px rgba(0,0,0,0.06);
}

.card:hover::after {
  opacity: 1;
}

.card:hover::before {
  left: 100%;
}

/* Icon Circle */
.icon-hover {
  width: 75px;
  height: 75px;
  margin: auto;
  border-radius: 50%;
  background: linear-gradient(135deg, #007bff, #00c6ff);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 15px;

  box-shadow: 0 10px 20px rgba(0,123,255,0.3);
  transition: 0.4s;
}

.icon-hover i {
  font-size: 32px;
  color: white;
}

/* Icon hover */
.card:hover .icon-hover {
  transform: scale(1.15) rotate(8deg);
  box-shadow: 0 15px 30px rgba(0,123,255,0.5);
}

/* Title */
.card h3 {
  font-weight: 600;
  color: #222;
  margin-bottom: 10px;
}

/* Text */
.card p {
  font-size: 14px;
  color: #666;
}

/* Ripple Effect */
.card:active::after {
  background: radial-gradient(circle, rgba(0,123,255,0.3), transparent 70%);
  opacity: 1;
}

/* Scroll Animation */
.show-cards {
  opacity: 0;
  transform: translateY(60px);
  transition: 1s ease;
}

.show-cards.show {
  opacity: 1;
  transform: translateY(0);
}

</style>

<div class="container card-container" id="feature-cards">

  <div class="row g-5 show-cards">

    <div class="col-md-4">
      <div class="card h-100">
        <div class="icon-hover"><i class='bx bxs-bar-chart-alt-2'></i></div>
        <h3>Excellence</h3>
        <p>Commitment to continuous growth, quality, and performance.</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card h-100">
        <div class="icon-hover"><i class='bx bxs-user-badge'></i></div>
        <h3>Empowerment</h3>
        <p>Helping individuals unlock their full potential with confidence.</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card h-100">
        <div class="icon-hover"><i class='bx bxs-extension'></i></div>
        <h3>Creativity</h3>
        <p>Driving innovation through ideas and imagination.</p>
      </div>
    </div>

  </div>

  <div class="row g-5 show-cards mt-4">

    <div class="col-md-4">
      <div class="card h-100">
        <div class="icon-hover"><i class='bx bxs-book'></i></div>
        <h3>Features</h3>
        <p>Smart tools that simplify management and improve efficiency.</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card h-100">
        <div class="icon-hover"><i class='bx bxs-star-half'></i></div>
        <h3>Achievement</h3>
        <p>Recognizing excellence in academics and leadership.</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card h-100">
        <div class="icon-hover"><i class='bx bxs-cuboid'></i></div>
        <h3>Goals</h3>
        <p>Building a future of collaboration, growth, and innovation.</p>
      </div>
    </div>

  </div>

</div>

<script>
// Scroll reveal animation
const cards = document.querySelectorAll(".show-cards");

window.addEventListener("scroll", () => {
  cards.forEach(card => {
    if (card.getBoundingClientRect().top < window.innerHeight - 100) {
      card.classList.add("show");
    }
  });
});
</script>