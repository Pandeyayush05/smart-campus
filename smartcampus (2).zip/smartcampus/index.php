<?php include('shared/_header.php'); ?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap');

body {
  font-family: "Poppins", sans-serif;
  margin: 0;
  overflow-x: hidden;
  background: linear-gradient(270deg, #0f2027, #203a43, #2c5364);
  background-size: 600% 600%;
  animation: gradientBG 10s ease infinite;
  color: white;
}

@keyframes gradientBG {
  0% {background-position:0% 50%;}
  50% {background-position:100% 50%;}
  100% {background-position:0% 50%;}
}

/* Glass Card */
.glass {
  backdrop-filter: blur(15px);
  background: rgba(255,255,255,0.1);
  border-radius: 20px;
  padding: 30px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.3);
}

/* Floating Shapes */
.shape {
  position: absolute;
  width: 200px;
  opacity: 0.2;
  animation: float 6s ease-in-out infinite;
}
@keyframes float {
  0%,100%{transform:translateY(0)}
  50%{transform:translateY(-30px)}
}

/* Neon Button */
.btn {
  background: linear-gradient(45deg, #00f2ff, #007bff);
  border: none;
  padding: 12px 25px;
  border-radius: 30px;
  color: white;
  transition: 0.4s;
  box-shadow: 0 0 10px #00f2ff;
}
.btn:hover {
  transform: scale(1.1);
  box-shadow: 0 0 20px #00f2ff, 0 0 40px #007bff;
}

/* Typing */
#typing {
  font-size: 2.5rem;
  font-weight: bold;
}

/* Image Tilt */
.tilt {
  transition: transform 0.2s;
}
.tilt:hover {
  transform: rotateY(10deg) rotateX(10deg) scale(1.05);
}

/* Fade-in */
.fade {
  opacity: 0;
  transform: translateY(50px);
  transition: 1s;
}
.fade.show {
  opacity: 1;
  transform: translateY(0);
}

/* Scroll Button */
#topBtn {
  position: fixed;
  bottom: 30px;
  right: 30px;
  background: #00f2ff;
  border: none;
  padding: 12px;
  border-radius: 50%;
  display: none;
  box-shadow: 0 0 20px #00f2ff;
}

/* Carousel Style */
.carousel-item img {
  border-radius: 20px;
  height: 400px;
  object-fit: cover;
}

.carousel-caption {
  background: rgba(0,0,0,0.5);
  border-radius: 10px;
  padding: 10px;
}
</style>

<body>

<!-- Floating Shapes -->
<img src="images/logo.png" class="shape" style="top:10%;left:5%;">
<img src="images/logo.png" class="shape" style="bottom:10%;right:5%;">

<main>
<div class="container mt-5">

<?php include('shared/_navbar.php'); ?>

<div class="row align-items-center">

<!-- TEXT -->
<div class="col-md-6 fade">
  <div class="glass">
    <h1>FUTURE IS HERE 🚀!!!</h1>
    <p>Manage students, automate systems, and explore the future with smart technology.</p>
    <a href="login.php" class="btn">🚀 Get Started</a>
  </div>
</div>

<!-- IMAGE -->
<div class="col-md-6 fade text-center">
  <img src="./images/logo1.png" class="img-fluid tilt">
</div>

</div>

<?php include('shared/feature-cards.php'); ?>

<hr class="mt-5">

<!-- CAROUSEL -->
<div id="carouselExample" class="carousel slide mt-4" data-bs-ride="carousel">
<div class="carousel-inner">

<div class="carousel-item active">
  <img src="images/back.png" class="d-block w-100">
  <div class="carousel-caption"><h5>Smart Dashboard</h5></div>
</div>

<div class="carousel-item">
  <img src="images/carousel2.jpg" class="d-block w-100">
  <div class="carousel-caption"><h5>Easy Management</h5></div>
</div>

<div class="carousel-item">
  <img src="images/carousel3.jpg" class="d-block w-100">
  <div class="carousel-caption"><h5>Powerful Features</h5></div>
</div>

</div>
<button class="carousel-control-prev" data-bs-target="#carouselExample" data-bs-slide="prev">
<span class="carousel-control-prev-icon"></span>
</button>
<button class="carousel-control-next" data-bs-target="#carouselExample" data-bs-slide="next">
<span class="carousel-control-next-icon"></span>
</button>
</div>

</div>
</main>

<!-- Scroll Button -->
<button id="topBtn">↑</button>

<script>
// Typing Effect with Loop
const words = ["Future is here 🚀"];
;

// Fade Animation
const faders = document.querySelectorAll('.fade');
window.addEventListener('scroll', () => {
  faders.forEach(el=>{
    if(el.getBoundingClientRect().top < window.innerHeight-100){
      el.classList.add('show');
    }
  });
});

// Scroll Top
const btn = document.getElementById("topBtn");
window.onscroll = ()=> btn.style.display = window.scrollY>200 ? "block":"none";
btn.onclick = ()=> window.scrollTo({top:0,behavior:'smooth'});
</script>

<?php include('shared/_footer.php'); ?>