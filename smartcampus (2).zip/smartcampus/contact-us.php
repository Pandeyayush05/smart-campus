<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$success = "";
$error = "";

if(isset($_POST['send'])){

$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

if($name!="" && $email!="" && $message!=""){

$mail = new PHPMailer(true);

try{
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'pandeyayush6184@gmail.com'; // 🔴 change
$mail->Password = 'hjwk gqeh eewk wbza';     // 🔴 change
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom($email, $name);
$mail->addAddress('pandeyayush6184@gmail.com');

$mail->isHTML(true);
$mail->Subject = "New Contact Message";
$mail->Body = "
<h3>New Message</h3>
<b>Name:</b> $name <br>
<b>Email:</b> $email <br>
<b>Message:</b><br> $message
";

$mail->send();
$success = "Message Sent Successfully ✔";

}catch(Exception $e){
$error = "Error: {$mail->ErrorInfo}";
}

}else{
$error = "Please Fill All Fields";
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SmartCampus Contact</title>

<style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap');

body{
margin:0;
font-family:Poppins;

/* Animated Gradient */
background: linear-gradient(-45deg,#1e3c72,#2a5298,#6dd5ed,#2193b0);
background-size:400% 400%;
animation:gradient 10s ease infinite;
}

@keyframes gradient{
0%{background-position:0% 50%}
50%{background-position:100% 50%}
100%{background-position:0% 50%}
}

/* Glass Container */
.container{
width:420px;
margin:80px auto;
padding:30px;

background:rgba(255,255,255,0.15);
backdrop-filter:blur(15px);

border-radius:20px;
box-shadow:0 10px 30px rgba(0,0,0,0.3);

animation:fadeIn 1s ease;
}

@keyframes fadeIn{
from{opacity:0;transform:translateY(-20px);}
to{opacity:1;transform:translateY(0);}
}

h1{
text-align:center;
color:white;
}

/* Input Fields */
input,textarea{
width:100%;
padding:12px;
margin:10px 0;

border:none;
border-radius:10px;

background:rgba(255,255,255,0.2);
color:white;

font-size:14px;
}

input::placeholder, textarea::placeholder{
color:#ddd;
}

/* Glow Effect */
input:focus, textarea:focus{
outline:none;
box-shadow:0 0 10px #00f2ff;
}

/* Button */
button{
width:100%;
padding:12px;

background:linear-gradient(45deg,#00f2ff,#007bff);
border:none;
border-radius:30px;

color:white;
font-size:16px;
cursor:pointer;

transition:0.3s;
}

button:hover{
transform:scale(1.1);
box-shadow:0 0 20px #00f2ff;
}

/* Messages */
.success{
background:#28a745;
color:white;
padding:10px;
border-radius:5px;
text-align:center;
margin-bottom:10px;
animation:fadeIn 0.5s;
}

.error{
background:#dc3545;
color:white;
padding:10px;
border-radius:5px;
text-align:center;
margin-bottom:10px;
}

/* Footer */
.footer{
text-align:center;
color:white;
margin-top:20px;
}

</style>
</head>

<body>

<div class="container">

<h1>Contact SmartCampus</h1>

<?php
if($success!="") echo "<div class='success'>$success</div>";
if($error!="") echo "<div class='error'>$error</div>";
?>

<form method="POST">

<input type="text" name="name" placeholder="👤 Your Name" required>

<input type="email" name="email" placeholder="📧 Your Email" required>

<textarea name="message" placeholder="💬 Your Message" required></textarea>

<button type="submit" name="send">🚀 Send Message</button>

</form>

</div>

<div class="footer">
© 2026 SmartCampus — All Rights Reserved.
</div>

</body>
</html>